<?php
 $en = array(
	'component:update:update_version' => 'Update Version',
	'component:update:update_url' => 'Update URL',
	'component:update:update_available' => 'Update Available',
);
ossn_register_languages('en', $en); 