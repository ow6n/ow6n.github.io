<?php
$en = array(
    'component:update:update_version' => 'Update Version',
    'component:update:update_url' => 'Update URL',
    'component:update:update_available' => 'Update verfügbar',
    'component:update:update_check:error' => 'Beim Zugriff auf verfügbare Updates ist folgender Fehler aufgetreten:',
);
ossn_register_languages('de', $en);