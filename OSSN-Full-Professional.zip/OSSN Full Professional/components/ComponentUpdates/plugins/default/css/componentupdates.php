.pad-left {
    margin-left: 20px;
}