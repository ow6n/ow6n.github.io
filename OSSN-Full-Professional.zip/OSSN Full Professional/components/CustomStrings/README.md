CustomStrings V1.0
==================

This component is meant to show you:

* how to overwrite existing language strings or to add new ones to your communitiy

Procedure:
1. Search complete Ossn file structure for the string you want to replace
2. and you'll find the corresponding placeholder in one of Ossn's language files
3. add exactly the same placeholder to the language files of this component
4. and replace the right part by your own words

As this component is getting initialized later than Ossn's default components,
the original string(s) will be overwritten by your own definition. 
