<?php

$custom_strings = array(
	'friends' => 'Homies',
	'my:own:placeholder' => 'I love Ossn!'
);
ossn_register_languages('en', $custom_strings);