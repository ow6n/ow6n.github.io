<?php

$custom_strings = array(
	'friends' => 'Kumpel',
	'my:own:placeholder' => 'Ich liebe Ossn!'
);
ossn_register_languages('de', $custom_strings);