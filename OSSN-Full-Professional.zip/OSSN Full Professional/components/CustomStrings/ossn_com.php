<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
//setting up path so we can use it in entire file 
//if your component folder have upper and lower case characters please use same here.
define('__CUSTOM_STRINGS__', ossn_route()->com . 'CustomStrings/');


//this function is used to initialize the component
function custom_strings() {

}
// this line is used to register the component
ossn_register_callback('ossn', 'init', 'custom_strings');
