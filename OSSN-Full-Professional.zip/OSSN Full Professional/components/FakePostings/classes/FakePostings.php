<?php

/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
class FakePosting extends OssnEntities {
		
		/**
		 * Initialize the object.
		 *
		 * @return void;
		 */
		public function initAttributes() {
				$this->OssnDatabase = new OssnDatabase;
		}

		/**
		 * Get user guids of inactive members
		 *
		 * @return object;
		 */
		public function getFakeUserIds() {
			self::initAttributes();

			$params           = array();
			$params['params'] = array(
					'a.guid'
			);
			$params['from']   = "ossn_users a";

			$params['wheres'] = array(
					"a.last_activity = 0"
			);

			$ids = $this->OssnDatabase->select($params, true);
			if($ids) {
				return $ids;
			}
			return false;
		}

		
}