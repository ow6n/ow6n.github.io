<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$count = abs ((int) input('count'));

// retrieve ids of users with no activity
$fp = new FakePosting;

for ($i = 0; $i < $count; $i++) {
	if ($fake_ids = $fp->getFakeUserIds()) {
		// count number of ids
		$fake_ids_cnt = count((array)$fake_ids);

		// generate 2 random array pointers from 0 to cnt - 1
		$random_poster_pointer = rand(0 , $fake_ids_cnt - 1);
		$random_owner_pointer = rand(0 , $fake_ids_cnt - 1);

		// retrieve random poster id from user id array
		$random_poster_guid = $fake_ids->{$random_poster_pointer}->guid;

		// retrieve random owner id from user id array
		$random_owner_guid = $fake_ids->{$random_owner_pointer}->guid;

		// retrieve a random posting from the fortunes database
		$fortune = new Fortune;
		$fortunes_dir = __FAKE_POSTINGS__ . 'vendors/fortunes';
		if (!$random_post = $fortune->QuoteFromDir($fortunes_dir)) {
			ossn_trigger_message(ossn_print('com:fakepostings:no:postings:available'), 'error');
			redirect(REF);
			exit;
		}
	
		// prepare wall posting
		$wall = new OssnWall;
		// refer to OssnWall/classes -> Post function
		// to see what needs to be initialized at minimum for a posting
	
		// we need:
		// 1. the id of the posting member
		$wall->poster_guid = $random_poster_guid;
	
		// 2. the wall's owner id of where to post, (the main newsfeed is owned by admin)
		$wall->owner_guid = $random_owner_guid;

		// 3. the posting text
		// actually, we need a little pre-processing here, otherwise some parts won't display correctly
		$post = htmlentities(preg_replace('/[\r\n]+/', '', $random_post), ENT_QUOTES, 'UTF-8');
	
		// finally, call Post function
		if(!$wall->Post($post)) {
			ossn_trigger_message(ossn_print('com:fakepostings:db:insert:failed'), 'error');
			redirect(REF);
			exit;
		}
	} else {
		ossn_trigger_message(ossn_print('com:fakepostings:no:inactive:users'), 'error');
		redirect(REF);
		exit;
	}
}
ossn_trigger_message(ossn_print('com:fakepostings:post:success', array($i)));
redirect(REF);
exit;

