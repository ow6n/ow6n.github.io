Fake Postings
=============

You have the "Fake Users" component installed, your community comes with impressing 5000 members,
but is still suffering from almost no user activities?

This component will be your friend then. As it allows you to generate thousands of random postings
on your wall retrieved from a so-called 'fortunes' database.

Driving your REAL members nuts with fake postings even made under their id can't be a good idea
on the other hand, and that's why the component is smart enough to select only members who
have never logged in.

There are 2 options to generate a fake posting:
1. manually from your admin panel by choosing Configure->Fake Postings
2. every 5 minutes, every hour, on fridays ... as you like ... by cron*

*Ask your provider whether there's an option to run cron jobs at your site.
If so, the command to be executed has to be:
php /YOUR_PHYSICAL_INSTALLATION_PATH_OF_OSSN/components/FakePostings/cronjobs/fakepost.php

Install the "System Info" component and find the line 'Install Dir'
in case you don't know YOUR_PHYSICAL_INSTALLATION_PATH_OF_OSSN.


Have fun!

V 2.0
cronjob error logging
cronjob adapted to Ossn 5.0 environment

V 1.1
allows to enter the number of postings to be generated

V 1.0
initial release