<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

// make sure this script has been called from the commandline !
if (PHP_SAPI === 'cli') {
	// load ossn environment
	$location = dirname(__FILE__);
	$start = $location . '/../../../system/start.php';
	define('OSSN_ALLOW_SYSTEM_START', TRUE);
	require_once($start);

	if(class_exists('OssnWall') && class_exists('FakePosting')) {
		// retrieve ids of users with no activity
		$fp = new FakePosting;
		if ($fake_ids = $fp->getFakeUserIds()) {
			// count number of ids
			$fake_ids_cnt = count((array)$fake_ids);

			// generate 2 random array pointers from 0 to cnt - 1
			$random_poster_pointer = rand(0 , $fake_ids_cnt - 1);
			$random_owner_pointer = rand(0 , $fake_ids_cnt - 1);

			// retrieve random poster id from user id array
			$random_poster_guid = $fake_ids->{$random_poster_pointer}->guid;

			// retrieve random owner id from user id array
			$random_owner_guid = $fake_ids->{$random_owner_pointer}->guid;

			// retrieve a random posting from the fortunes database
			$fortune = new Fortune;
			$fortunes_dir = __FAKE_POSTINGS__ . 'vendors/fortunes';
			if (!$random_post = $fortune->QuoteFromDir($fortunes_dir)) {
				error_log(ossn_print('com:fakepostings:no:postings:available'));
				exit;
			}
	
			// prepare wall posting
			$wall = new OssnWall;
			// refer to OssnWall/classes -> Post function
			// to see what needs to be initialized at minimum for a posting
	
			// we need:
			// 1. the id of the posting member
			$wall->poster_guid = $random_poster_guid;
	
			// 2. the wall's owner id of where to post, (the main newsfeed is owned by admin)
			$wall->owner_guid = $random_owner_guid;

			// 3. the posting text
			// actually, we need a little pre-processing here, otherwise some parts won't display correctly
			$post = htmlentities(preg_replace('/[\r\n]+/', '', $random_post), ENT_QUOTES, 'UTF-8');
	
			// finally, call Post function
			if(! $wall->Post($post)) {
				error_log(ossn_print('com:fakepostings:db:insert:failed'));
				exit;
			}
		} else {
			error_log(ossn_print('com:fakepostings:no:inactive:users'));
			exit;
		}
	} else {
		error_log('Wall/FakePostings component(s) not installed or disabled - posting aborted');
		exit;
	}
} else {
	echo "No hacking, please.";
}