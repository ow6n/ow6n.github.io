<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$en = array(
    'fakepostings' => 'Fake Postings',
    'FakePostings' => 'Fake Postings',
	'com:fakepostings:button:post' => 'Generate',
	'com:fakepostings:instruction' => 'Create random posting(s) in your community',
	'com:fakepostings:input:postings:count' => 'Number of postings',
	// processing ...
	'com:fakepostings:post:success' => '%s posting(s) successfully created',
	'com:fakepostings:no:inactive:users' => 'No inactive members found - posting aborted',
	'com:fakepostings:component:missing' => 'Wall/FakePostings component(s) not installed or disabled - posting aborted',
	'com:fakepostings:no:postings:available' => 'No postings available - make sure you have a valid fortunes database installed',
	// database errors
	'com:fakepostings:db:insert:failed' => "Database error: The posting could not be saved",
);
ossn_register_languages('tr', $en); 
