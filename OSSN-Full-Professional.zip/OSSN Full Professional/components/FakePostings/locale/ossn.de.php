<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$de = array(
    'fakepostings' => 'Fake Postings',
    'FakePostings' => 'Fake Postings',
	'com:fakepostings:button:post' => 'Generieren',
	'com:fakepostings:instruction' => 'Zufällige(n) Beiträge(Beitrag) in deinem sozialen Netzwerk erzeugen',
	'com:fakepostings:input:postings:count' => 'Anzahl der Beiträge',
	// processing ...
	'com:fakepostings:post:success' => '%s Beitrag(Beiträge) wurde(n) erfolgreich generiert',
	'com:fakepostings:no:inactive:users' => 'Es wurden keine inaktiven Mitglieder gefunden - Posting abgebrochen',
	'com:fakepostings:component:missing' => 'Wall/FakePostings Komponente(n) nicht installiert oder deaktiviert - Posting abgebrochen',
	'com:fakepostings:no:postings:available' => 'Keine Beiträge verfügbar - stelle sicher, dass eine funktionierende fortunes Datenbank installiert ist',
	// database errors
	'com:fakepostings:db:insert:failed' => "Datenbank-Fehler: Das Posting konnte nicht gespeichert werden",
);
ossn_register_languages('de', $de); 
