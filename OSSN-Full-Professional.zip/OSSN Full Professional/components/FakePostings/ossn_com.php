<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

define('__FAKE_POSTINGS__', ossn_route()->com . 'FakePostings/');
require_once(__FAKE_POSTINGS__ . 'classes/FakePostings.php');
require_once(__FAKE_POSTINGS__ . 'classes/fortune.php');

function fake_postings_init() {
	// back end
	if(ossn_isAdminLoggedin() && class_exists('OssnWall')){
		ossn_register_com_panel('FakePostings', 'fakepost');
		ossn_register_action('FakePostings/admin/fakepost', __FAKE_POSTINGS__ . 'actions/FakePostings/admin/fakepost.php');		
	}
}

ossn_register_callback('ossn', 'init', 'fake_postings_init');
