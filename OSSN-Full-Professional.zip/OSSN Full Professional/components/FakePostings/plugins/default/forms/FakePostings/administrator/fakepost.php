<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

echo ossn_print('com:fakepostings:instruction');
?>
<br />
<br /> 
<label><?php echo ossn_print('com:fakepostings:input:postings:count');?></label>
<input type="text" name="count" value="1" />
<br />
<br />
<br />
<br />
<br />
<input type="submit" value="<?php echo ossn_print('com:fakepostings:button:post');?>" class="btn btn-success"/>
