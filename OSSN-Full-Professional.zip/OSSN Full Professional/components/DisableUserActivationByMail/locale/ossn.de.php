<?php
$en = array(
	'com:disable:user:activation:by:mail:validation:error' => 'Validation failed - please verify the link you sent and try again.',
	'com:disable:user:activation:by:mail:validated:activation:notified' => 'Validation successful - your account will be activated soon.<br>You may re-visit this link in order to check whether your account has been activated.',
	'com:disable:user:activation:by:mail:validated:activation:pending' => 'Stay tuned - the admin has been notified - your account will be activated soon.',
	'com:disable:user:activation:by:mail:account:activated' => 'Your account has been activated - feel free to login.',
	'com:disable:user:activation:by:mail:admin:mail:subject' => 'New member activation pending',
	'com:disable:user:activation:by:mail:admin:mail:body' => 'A new activation request from %s %s is pending on %s',
);
ossn_register_languages('de', $en); 
