<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
function com_disable_user_activation_by_email() {
	ossn_unregister_page('uservalidate');
	ossn_register_page('uservalidate', 'com_disable_user_activation_by_email_uservalidate_pagehandler');
}

function com_disable_user_activation_by_email_uservalidate_pagehandler($pages) {
	$page = $pages[0];
	if(empty($page)) {
		echo ossn_error_page();
	}
	switch($page) {
		case 'activate':
			if(!empty($pages[1]) && !empty($pages[2])) {
				$user       = new OssnUser;
				$user->guid = $pages[1];
				$unvalidated_user = $user->getUser();
				if(strlen($unvalidated_user->activation)) {
					// activation still pending
					// verify the relevant first part only, because we will add a ':visited' later
					if(substr($unvalidated_user->activation, 0, 32) == $pages[2]) {
						// yes, matching!
						if($unvalidated_user->activation == $pages[2]) {
							// still no trailing ':visited'
							// => first time user validating request - send email to admin !
							$mail_recipient = ossn_site_settings('owner_email');
							$mail_subject   = ossn_print('com:disable:user:activation:by:mail:admin:mail:subject');
							$mail_body      = ossn_print('com:disable:user:activation:by:mail:admin:mail:body', array(
									$unvalidated_user->first_name,
									$unvalidated_user->last_name,
									ossn_site_url('administrator/unvalidated_users')
							));
							$mailer         = new OssnMail;
							$mailer->NotifiyUser($mail_recipient, $mail_subject, $mail_body);
							// mark user record that a validating request has been sent right now
							// to avoid subsequent admin mails
							$params['table']  = 'ossn_users';
							$params['names']  = array(
								'activation'
							);
							$params['values'] = array(
								$unvalidated_user->activation . ':visited'
							);
							$params['wheres'] = array(
								"guid='{$unvalidated_user->guid}'"
							);
							$OssnDatabase     = new OssnDatabase;
							$OssnDatabase->update($params);
							ossn_trigger_message(ossn_print('com:disable:user:activation:by:mail:validated:activation:notified'), 'success');
							redirect();
							exit;
						}
						// keys are matching and ':visited' already in place
						ossn_trigger_message(ossn_print('com:disable:user:activation:by:mail:validated:activation:pending'), 'success');
						redirect();
						exit;
					} else {
						// wrong activation key submitted
						ossn_trigger_message(ossn_print('com:disable:user:activation:by:mail:validation:error'), 'error');
						redirect();
						exit;
					}
				} else {
					// member already activated by admin
					ossn_trigger_message(ossn_print('com:disable:user:activation:by:mail:account:activated'), 'success');
					redirect();
				}
			}
		break;
	}
}

ossn_register_callback('ossn', 'init', 'com_disable_user_activation_by_email');
