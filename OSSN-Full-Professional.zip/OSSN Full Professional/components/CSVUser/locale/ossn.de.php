<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014-2016 SOFTLAB24 LIMITED
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$de = array(
    'csvuser' => 'CSV Benutzer Import',
    'CSVUser' => 'CSV Benutzer Import',
	'com:csvuser:send:activation:request' => 'Aktivierungs-Schlüssel per mail an die importierten Benutzer schicken',
	'com:csvuser:add:group:membership' => 'Die importierten Benutzer werden Mitglied von ',
	'com:csvuser:group:selection:no:group' => 'KEINER Gruppe',
	'com:csvuser:file:name:label' => 'Wähle eine CSV Datei zum Hochladen',
	'com:csvuser:button:import' => 'Importieren',
	'com:csvuser:instruction' => 'Lade eine gültige CSV Datei (z.B. <i>example.csv</i>) mit Benutzern hoch, die du zu deiner Gemeinschaft hinzufügen möchtest.',
	// processing ...
	'com:csvuser:import:success' => 'Die CSV Datei wurde erfolgreich importiert',
	// upload errors
	'com:csvuser:upload:max:file:size:exceeded' => 'Fehler 1 beim Hochladen: Die CSV Datei ist größer als die PHP Vorgabe <i>upload_max_filesize</i> zulässt',
	'com:csvuser:upload:incomplete' => 'Fehler 3 beim Hochladen: die hochgeladene CSV Datei ist nicht komplett - versuch es noch einmal',
	'com:csvuser:upload:no:file:selected' => 'Fehler 4 beim Hochladen: Dateiangabe fehlt - Bitte wähle eine gültige CSV Datei und wiederhole den Vorgang',
	'com:csvuser:upload:tmpfolder:missing' => 'Fehler 6 beim Hochladen: Dein Server hat kein Verzeichnis für temporäre Dateien',
	'com:csvuser:upload:write:failed' => 'Fehler 7 beim Hochladen: Dein Server konnte die CSV Datei nicht speichern',
	'com:csvuser:upload:stopped:by:extension' => 'Fehler 8 beim Hochladen: Eine PHP Erweiterung hat das Hochladen gestoppt',
	'com:csvuser:upload:unknown:error' => 'Unbekannter Fehler beim Hochladen %s - bitte kontakte deinen Provider',
	// csv file errors
	'com:csvuser:file:structure:invalid' => 'Die Struktur der CSV Datei ist fehlerhaft und/oder es fehlen Pflichtangaben',
	'com:csvuser:duplicate:entries' => 'In der CSV Datei wurden doppelte Benutzernamen und/oder Mail-Adressen gefunden',
	// ossn compatibility/database errors
	'com:csvuser:username:invalid' => "Der Benutzername '%s' in Zeile %s ist entweder zu kurz oder enthält ungültige Zeichen",
	'com:csvuser:username:exists' => "Der Benutzername '%s' in Zeile %s ist schon in Benutzung",
	'com:csvuser:email:invalid' => "Die Email-Adresse '%s' in Zeile %s ist ungültig",
	'com:csvuser:email:exists' => "Die Email-Adresse '%s' in Zeile %s ist schon in Benutzung",
	'com:csvuser:firstname:short' => "Der Vorname '%s' in Zeile %s fehlt oder ist zu kurz",
	'com:csvuser:lastname:short' => "Der Nachname '%s' in Zeile %s fehlt oder ist zu kurz",
	'com:csvuser:db:insert:failed' => "Datenbank-Fehler: %s von %s Benutzern und %s Gruppen-Mitgliedschaften konnten nicht gespeichert werden",
);
ossn_register_languages('de', $de); 
