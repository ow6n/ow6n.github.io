<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014-2016 SOFTLAB24 LIMITED
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$en = array(
    'csvuser' => 'CSV User Import',
    'CSVUser' => 'CSV User Import',
	'com:csvuser:send:activation:request' => 'Mail activation key to imported users',
	'com:csvuser:add:group:membership' => 'Make imported users a member of ',
	'com:csvuser:group:selection:no:group' => 'NO group',
	'com:csvuser:file:name:label' => 'Choose CSV file to upload',
	'com:csvuser:button:import' => 'Import',
	'com:csvuser:instruction' => 'Upload a valid CSV file (see <i>example.csv</i>) with user data to be imported to your community.',
	// processing ...
	'com:csvuser:import:success' => 'CSV file imported successfully',
	// upload errors
	'com:csvuser:upload:max:file:size:exceeded' => 'Upload error 1: CSV file exceeds PHP <i>upload_max_filesize</i> limit',
	'com:csvuser:upload:incomplete' => 'Upload error 3: upload of CSV file incomplete - please try again',
	'com:csvuser:upload:no:file:selected' => 'Upload error 4: Missing file name - please select a valid CSV file and try again',
	'com:csvuser:upload:tmpfolder:missing' => 'Upload error 6: Your server is missing a directory for temporary files',
	'com:csvuser:upload:write:failed' => 'Upload error 7: Your server failed to save the CSV file',
	'com:csvuser:upload:stopped:by:extension' => 'Upload error 8: Some PHP extension has stopped your upload',
	'com:csvuser:upload:unknown:error' => 'Unknown upload error %s - please consult your provider',
	// csv file errors
	'com:csvuser:file:structure:invalid' => 'Invalid CSV file structure and/or mandantory entries missing',
	'com:csvuser:duplicate:entries' => 'Duplicate usernames and/or emails found in CSV file',
	// ossn compatibility/database errors
	'com:csvuser:username:invalid' => "Username '%s' too short or invalid on line %s",
	'com:csvuser:username:exists' => "Username '%s' on line %s is already in use",
	'com:csvuser:email:invalid' => "Email '%s' invalid on line %s",
	'com:csvuser:email:exists' => "Email '%s' on line %s is already in use",
	'com:csvuser:firstname:short' => "Firstname '%s' too short or missing on line %s",
	'com:csvuser:lastname:short' => "Lastname '%s' too short or missing on line %s",
	'com:csvuser:db:insert:failed' => "Database error: Failed to insert %s of %s users and %s group memberships",
);
ossn_register_languages('en', $en); 
