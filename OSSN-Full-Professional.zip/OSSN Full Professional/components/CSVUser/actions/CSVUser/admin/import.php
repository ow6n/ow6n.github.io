<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright 2014-2016 SOFTLAB24 LIMITED
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
define (COLUMNS, 6);
$send_activation_key = input('send_activation_key');
$group = input('group');
$error_msg = false;
$error_cnt = 0;
$group_error_cnt = 0;

if($upload_error = $_FILES['csvfile']['error']) {
	// exit on upload errors
	switch($upload_error) {
		case 1:
			$error_msg = ossn_print('com:csvuser:upload:max:file:size:exceeded');
			break;
		case 3:
			$error_msg = ossn_print('com:csvuser:upload:incomplete');
			break;
		case 4:
			$error_msg = ossn_print('com:csvuser:upload:no:file:selected');
			break;
		case 6:
			$error_msg = ossn_print('com:csvuser:upload:tmpfolder:missing');
			break;
		case 7:
			$error_msg = ossn_print('com:csvuser:upload:write:failed');
			break;
		case 8:
			$error_msg = ossn_print('com:csvuser:upload:stopped:by:extension');
			break;
		default:
			$error_msg = ossn_print('com:csvuser:upload:unknown:error', array($upload_error));
	}
} else {
	// upload ok, verify file integrity now
	$fh = fopen($_FILES['csvfile']['tmp_name'], 'r+');
	$table = array();
	while(($row = fgetcsv($fh, 1024)) !== FALSE ) {
		if(count($row) != COLUMNS) {
			// all columns are mandantory, less or more columns are an error condition!
			$error_cnt++;
			break;
		} else {
			// replace numerical keys for later duplicate checking
			$row['username']   = $row[0]; unset($row[0]);
			$row['email']      = $row[1]; unset($row[1]);
			$row['first_name'] = $row[2]; unset($row[2]);
			$row['last_name']  = $row[3]; unset($row[3]);
			$row['gender']     = $row[4]; unset($row[4]);
			$row['birthdate']  = $row[5]; unset($row[5]);
			$table[] = $row;
		}
	}
	fclose($fh);
	
	if($table[0]['username'] != 'username' || $table[0]['email'] != 'email' || $table[0]['first_name'] != 'first_name'
		|| $table[0]['last_name'] != 'last_name' || $table[0]['gender'] != 'gender' || $table[0]['birthdate'] != 'birthdate' || $error_cnt > 0) {
		$error_msg = ossn_print('com:csvuser:file:structure:invalid');
	} else {
		// check for duplicate usernames and emails
		$orig_table = $table;
		$table = removeDuplicates($table, 'username');
		$table = removeDuplicates($table, 'email');
		if($table != $orig_table) {
			$error_msg = ossn_print('com:csvuser:duplicate:entries');
		} else {
			// csv file verified and ok
			// remove header line
			unset($table[0]);
			$lines_total = count($table);
			// but remember that header line is still in original csv, thus incease row counter
			// to deliver the correct line number in error case
			$row_cnt = 1;
			// verify all csv file rows before actually inserting into db
			// otherwise we might end up with a partly imported csv file which is hard to handle
			$add = new OssnUser;
			foreach($table as $row) {
				$row_cnt++;
				$add->username = $row['username'];
				$add->email = $row['email'];
				if (!$add->isUsername()) {
					$error_msg = ossn_print('com:csvuser:username:invalid', array($row['username'], $row_cnt));
					break;
				}
				if($add->isOssnUsername()){
					$error_msg = ossn_print('com:csvuser:username:exists', array($row['username'], $row_cnt));
					break;
				}
				if(!$add->isEmail()){
					$error_msg = ossn_print('com:csvuser:email:invalid', array($row['email'], $row_cnt));
					break;
				}
				if($add->isOssnEmail()){
					$error_msg = ossn_print('com:csvuser:email:exists', array($row['email'], $row_cnt));
					break;
				}
				if(strlen($row['first_name']) < 2) {
					$error_msg = ossn_print('com:csvuser:firstname:short', array($row['first_name'], $row_cnt));
					break;
				}
				if(strlen($row['last_name']) < 2) {
					$error_msg = ossn_print('com:csvuser:lastname:short', array($row['last_name'], $row_cnt));
					break;
				}
			}
			if(!$error_msg) {
				// no errors, insert rows into db now
				foreach($table as $row) {
					$add->username = $row['username'];
					$add->email = $row['email'];
					$add->first_name = $row['first_name'];
					$add->last_name = $row['last_name'];
					// initially, set password to email 
					$add->password = $add->email;
					// if no or invalid gender: set gender to male
					if($row['gender'] == 'f') {
						$add->gender = 'female';
					} else {
						$add->gender = 'male';
					}
					// if no or invalid birthdate: set birthdate to current day
					$add->birthdate = verifyDate($row['birthdate']);
					// either send activation key to users by email (as with manual registration)
					// or send no mail and activate users automatically on import
					if($send_activation_key) {
						$add->sendactiviation = true;
						$add->validated = false;
					} else {
						$add->sendactiviation = false;
						$add->validated = true;
					}
					if (!$add->addUser()) {
						// since everything is pre-checked, this should never happen - but who knwows ...
						$error_cnt++;
						$error_msg = ossn_print('com:csvuser:db:insert:failed', array($error_cnt, $lines_total, $group_error_cnt));
					} else {
						// make the CSV user a member of a selected group ?
						if ($group) {
							// actually, we can retrieve the user_id here like
							$current_user_id = $add->owner_guid;
							// because it's still left in memory from inserting the user's 'gender' record into the entities table
							// thus, we don't need to fetch the user record at all :)
						
							// build up group membership relations now
							if (!ossn_add_relation($current_user_id, $group, 'group:join') ||
							!ossn_add_relation($group, $current_user_id, 'group:join:approve')) {
								$group_error_cnt++;
								$error_msg = ossn_print('com:csvuser:db:insert:failed', array($error_cnt, $lines_total, $group_error_cnt));
							}
						}
					}
				}
			}
		}
	}
}

if($error_msg) {
	ossn_trigger_message($error_msg, 'error');
} else {
	ossn_trigger_message(ossn_print('com:csvuser:import:success'));
}
redirect(REF);

function removeDuplicates($array, $key) {
    $temp_array = array();
    $i = 0;
    $key_array = array();
   
    foreach($array as $val) {
        if (!in_array($val[$key], $key_array)) {
            $key_array[$i] = $val[$key];
            $temp_array[$i] = $val;
        }
        $i++;
    }
    return $temp_array;
}

function verifyDate($date){
	if (strlen($date) < 10 || !preg_match("/^[0-9\/]+$/", $date)) {
		return date('d/m/Y', time());
	}
	return $date;
}
