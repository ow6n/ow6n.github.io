<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright 2014-2016 SOFTLAB24 LIMITED
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

echo ossn_print('com:csvuser:instruction');
?> 
<br />
<br />
<br />
<input type="checkbox" name="send_activation_key" value=true checked> <?php echo ossn_print('com:csvuser:send:activation:request'); ?>
<br />
<br />

<?php
if(class_exists('OssnGroup')) {
	$ossngroup = new OssnGroup;
	if ($groups = $ossngroup->getGroups()) {
?>
<div class="row">
<div class="col-md-4"><br><?php echo ossn_print('com:csvuser:add:group:membership'); ?> 
</div>
<div class="col-md-4" style="margin:5px">
	<select name="group">
	<option value="0"><?php echo ossn_print('com:csvuser:group:selection:no:group'); ?></option>
<?php
		foreach($groups as $group) {
			echo "<option value=\"" . $group->guid . "\">" . $group->title . "</option>";
		}
?>
</select>
</div>
<div class="col-md-4">.
</div>
</div>
<br />
<?php
	}
}
?>

<label><?php echo ossn_print('com:csvuser:file:name:label'); ?></label>
<input type="file" name="csvfile" />
<br />
<br />
<input type="submit" value="<?php echo ossn_print('com:csvuser:button:import');?>" class="btn btn-success"/>
