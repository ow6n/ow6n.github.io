CSV User Import
===============

V2.0
This component allows you to import a long list of new members to your Ossn community from a so-called 'csv' file
in just one step.
As an option you may make them a member of a group of your choice. 


Before making use of this component, a few prerequisites must be definitely met:

- you have made a backup of your Ossn database
- you have the System Info component up and running (https://www.opensource-socialnetwork.org/component/view/1963/system-info)
- you have a basic knowledge of csv files and how to create one (http://www.computerhope.com/issues/ch001356.htm)


As for the last topic, this component includes a ready-to-use CSV file named example.csv. Just open this file
from a local directory with a simple text editor like notepad and have a look at the first line now: 

[username,email,first_name,last_name,gender,birthdate]

This line is called the "header", it is mandantory, and it defines the order of all following user records. Don't change it. 
All 6 fields have to be in line with Ossn's internal data structures, thus it makes sense to have a closer look at each of them.

- username: has to be at least 5 characters long, no spaces, no special characters, just a-z, A-Z, and numbers are allowed
- email: a valid email address, since it will be used to send activation keys to your new users
- first_name: has to be at least 2 characters long, spaces and special characters and numbers are allowed
- last_name: same as first_name
- gender: must be 'f' for female users, or 'm' for males. Any other invalid or empty entries will be replaced by 'male'
- birthdate: the only accepted format is dd/mm/yyyy. Using any other format or leaving this field blank will make the component
  using the current date as birthdate

  
All following lines must be user records - one user per line

[Adam03,adam@z-mans.net,Adam D.,Schießbörger,m,19/03/1993]

this is the most complete record, gender and birthdate are explicitely set and of correct format, using some special chars with
the first and last name


[tomato,tomato@z-mans.net,rita,red,,]

the most incomplete record, and although a woman most obviously, Rita will be set to 'male' since no gender has been set.
Note, that the commas must to be in place, though. Otherwise the number of fields will not match with the header's 6 columns.


[sjacobs,tomato@z-mans.net,Susan,Jacobs,f,]
Susan will be set to 'female' correctly, but again the birthdate will be set to the day of insertion because the last column has been left empty

It's a good idea to make sure all user records are as complete as possible if you don't want your members to correct their data later manually.
And don't forget: The first 4 columns can't be empty - if so, the component will throw out an error and exit.
Actually, there's a lot of built-in error checking in this component, as Ossn won't work with duplicate usernames or email addresses for example.


Okay, let's go ahead. After installing and enabling this component navigate to Configure->CSV User Import.

The next step is to decide whether you want the component to send an activation key to every newly imported user. This option is checked
by default, but note that this may really stress your server with larger csv files. And especially on a shared host it can't be wrong
to ask your provider first, if these kind of mass mailings are allowed at all.

If you uncheck this option, no mail will be sent and all users will be switched to 'active' automatically. Still playing
around with the example.csv, this may be the preferred option in the beginning. Thus, uncheck "Mail activation key to imported users"
for now, and click the [Browse...] button to select the example.csv file. Finally click the [Import] button.

Good luck!

One last important thing to note:
Since your member's old passwords are long encrypted strings nobody would love to remember,
and dealing with clear text passwords is no good idea either,
the members's new password has been saved as a copy of his email address.
Referring to Adam03 from above that means: He will be able to log in with the password: adam@z-mans.net

So, please instruct your new members to change their password once after logging in for the first time.