<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright 2014-2016 SOFTLAB24 LIMITED
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

define('__CSV_USER__', ossn_route()->com . 'CSVUser/');

function csv_user_init() {
	// back end
	if(ossn_isAdminLoggedin()){
		ossn_register_com_panel('CSVUser', 'import');
		ossn_register_action('CSVUser/admin/import', __CSV_USER__ . 'actions/CSVUser/admin/import.php');		
	}	
}

ossn_register_callback('ossn', 'init', 'csv_user_init');
