<?php
/**
 *    OpenSource-SocialNetwork
 *
 * @package   (webbehinds.com).ossn
 * @author    OSSN Core Team | Sathish Kumar <info@opensource-socialnetwork.com>
 * @copyright 2014 webbehinds
 * @license   General Public Licence http://opensource-socialnetwork.com/licence
 * @link      http://www.opensource-socialnetwork.com/licence
 */
$en = array(
    'contact' => 'Contact',
    'contact:body' => 'Name 	: %s

Email 	: %s		

Message  : %s ',
);
ossn_register_languages('en', $en); 
