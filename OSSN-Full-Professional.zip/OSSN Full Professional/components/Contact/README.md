# contact
Contact page plugin for ossn (opensource-socialnetwork)



OSSN is released under the GNU General Public License (GPL) Version 2

Component:

This Component used to show the Contact page for the user to send there feedback

In this component i have used the following things that is usefull for others to build component

1.How to register page ?
2.How to write action ?
3.How to write the setting page ?

For the above question you can get the answer by seeing this plugin .
I hope this will helpfull for you guys to build a new one.

IF you want to change the map . Please go to this page and change the iframe code with your iframe embed from google map .

    components/contact/forms/administrator/contactform.php

Translation for other language is not done

Its a sample plugin for other to work on . If you have any issues contact me
or post the issue in the github or community . we are ready to help you .

