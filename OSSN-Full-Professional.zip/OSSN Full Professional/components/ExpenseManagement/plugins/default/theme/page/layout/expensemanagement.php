<div class="container">
	<?php echo $params['content']; ?>
</div>    
<div style="display:none;">
		   <?php echo ossn_plugin_view('theme/page/elements/footer');?>
</div>                                  
