<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$blog_content = ossn_call_hook('textarea', 'purify', false, html_entity_decode($params['blog']->description)); 
?>
<div class="ossn-page-contents">
	<div class="blog">
    	<div class="blog-title"><?php echo $params['blog']->title;?></div>
		<div class="blog-body"><?php echo $blog_content;?></div> 
		<div class="aba">
			<?php $user = ossn_user_by_guid($params['blog']->owner_guid); ?>
			<div class="user-data">
				<div class="author">
           			<img src="<?php echo $user->iconURL()->small;?>" />
                    <div class="name"><a href="<?php echo $user->profileURL();?>"><?php echo $user->fullname;?></a></div>
				</div>
				<div class="date">
					<span class="time-created"><?php echo date("F d, Y", $params['blog']->time_created);?></span>
				</div>
			</div>
			<div class="controls">
				<?php if(ossn_loggedin_user() && (ossn_loggedin_user()->guid == $params['blog']->owner_guid || ossn_loggedin_user()->canModerate())){ ?>
				<a href="<?php echo $params['blog']->deleteURL();?>" class="btn btn-danger"><?php echo ossn_print('delete');?></a>
				<a href="javascript:history.back()" class="btn btn-info"><?php echo ossn_print('back');?></a>
				<span id="BlogShareButton" class="btn btn-default"><?php echo ossn_print('com:blog:blog:share:button');?></span>
				<a href="<?php echo $params['blog']->profileURL('edit');?>" class="btn btn-success"><?php echo ossn_print('edit');?></a>
				<?php } else {?>
				<a href="javascript:history.back()" class="btn btn-info"><?php echo ossn_print('back');?></a>
				<span id="BlogShareButton" class="btn btn-default"><?php echo ossn_print('com:blog:blog:share:button');?></span>
				<?php } ?>
			</div>
		</div>
		<div class="comments-list">
			<?php 
			if($params['blog_entity']) {
			$vars['entity'] = $params['blog_entity'];
			echo ossn_plugin_view('entity/comment/like/share/view', $vars);
			}
			?>
		</div>
	</div>
</div>
<?php
$http = 'http';
if(isset($_SERVER['HTTPS'])){
	$http = 'https';
}
$host = $_SERVER['HTTP_HOST'];
$requestUri = $_SERVER['REQUEST_URI'];
$current_url = $http . '://' . htmlentities($host) . htmlentities($requestUri);
$shared_url = str_replace('blog/view', 'sharedblogs/view', $current_url);
?>
<div id="blog-share-dialog" title="&nbsp;<?php echo ossn_print('com:blog:blog:share:widget:header');?>">
  <p style="float:left; margin:0 0px 20px 0; font-size: 12px;"><br><?php echo $shared_url;?></p>
</div>