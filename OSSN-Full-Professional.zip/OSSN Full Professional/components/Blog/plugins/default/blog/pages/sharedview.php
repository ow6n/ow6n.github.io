<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$blog_content = ossn_call_hook('textarea', 'purify', false, html_entity_decode($params['blog']->description)); 
?>
<div class="col-md-12">
<div class="ossn-page-contents">
	<div class="blog">
		<div class="aba">
			<?php $user = ossn_user_by_guid($params['blog']->owner_guid); ?>
			<div class="user-data">
				<div class="author">
           			<img src="<?php echo $user->iconURL()->small;?>" />
                    <div class="name"><?php echo $user->fullname;?></div>
				</div>
				<div class="date">
					<span class="time-created"><?php echo date("F d, Y", $params['blog']->time_created);?></span>
				</div>
			</div>
		</div>
    	<div class="blog-title"><?php echo $params['blog']->title;?></div>
		<div class="blog-body"><?php echo $blog_content;?></div> 
	</div>
</div>
</div>