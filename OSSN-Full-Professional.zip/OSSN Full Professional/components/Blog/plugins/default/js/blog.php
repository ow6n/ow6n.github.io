$(document).ready(function() {
	$('.menu-section-blogs').find('i').removeClass('fa-angle-right').addClass('fa-edit');
    $('#blog-share-dialog').dialog({
        autoOpen:false,
		resizable: false,
		draggable: false,
    }).prev(".ui-dialog-titlebar, .ui-widget-header").css({"padding":"0px", "border":"0px", "background":"unset", "background-color":"#e5e5e5", "border-radius":"0px", "font-size":"12px"});
});

$(function() {
    $('#BlogShareButton').click(function(e) {
        e.preventDefault();
        $('#blog-share-dialog').dialog('open');
    });
});
