.blog .blog-title {
    font-size: 17px;
    font-weight: bold;
    padding-bottom: 5px;
    margin-bottom: 10px;
    border-bottom: 1px solid #eee;
}
.blog .blog-body {

}
.blog .aba .author img {
    border-radius: 100px;
    display: inline-block;
    float: left;
}
.blog .aba .author .name {
	margin-left: 60px;
}
.blog .aba .date {
    margin-left: 60px;
        padding-bottom: 5px;
}
.blog .aba .date span {
	font-size:13px;
}
.blog .aba {
    background: #F9F9F9;
	margin-bottom: 10px;
}
.blog .aba .aba-shared{
    margin-top: 0px;
    background: #F9F9F9;
    padding: 10px;
}
.blog .aba .user-data {
    display: inline-block;
}
.blog .aba .controls {
    display: inline-block;
    float: right;
    padding: 10px;
}
.blog .aba .controls a {

}
.blog .blog-item {

}
.row .blog-item a {
    display: block;
    padding: 8px;
	padding-left: 0px;
    border-bottom: 1px solid #eee;
    font-weight: bold;
}
.blog .comments-list {
	margin-left: unset;
	margin-right: unset;
}
.blog .controls {
	float: right;
}
.blog-list-sort-option {
	float: right;
	margin-top: -30px;
	margin-right: 6px;
}
.ossn-notification-icon-blog {
    display: inline-block;
}
.ossn-notification-icon-blog:before {
	content: "\f044";
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    font-size: 18px;
}
.menu-section-item-addblog:before {
    content: "\f067" !important
}
.menu-section-item-myblogs:before {
    content: "\f044" !important
}
.menu-section-item-allblogs:before {
    content: "\f044" !important
}
.ossn-menu-search-com-blog-search-blogs .text::before {
    font-family: FontAwesome;
    content: "\f044";
    display: absolute;
    padding-right: 10px;
    vertical-align: middle;
    float: left;
}
