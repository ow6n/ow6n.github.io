<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

echo ossn_print('com:delete:messages:instruction');
?>
<br />
<br /> 
<br />
<label><?php echo ossn_print('com:delete:messages:input:days:count');?></label>
<input type="text" name="count" value="28" />
<br />

<input id="delete-messages-checkbox" type="checkbox" name="simulate_delete" value="checked" checked> <?php echo ossn_print('com:delete:messages:checkbox:simulate:delete');?> 
<br />
<br />
<input id="delete-messages-button" type="submit" value="<?php echo ossn_print('com:delete:messages:button:delete');?>" class="btn"/>
