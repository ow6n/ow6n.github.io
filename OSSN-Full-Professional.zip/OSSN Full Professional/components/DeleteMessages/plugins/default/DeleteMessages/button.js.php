//<script>
Ossn.RegisterStartupFunction(function() {
	$(document).ready(function() {
		$('#delete-messages-checkbox'). click(function(){
			if($(this).prop("checked") == true){
				$(this).blur();
				$('#delete-messages-button').removeClass('btn-danger');
			}
			else if($(this).prop("checked") == false){
				$(this).blur();
				$('#delete-messages-button').addClass('btn-danger');
			}
		});
	});
});