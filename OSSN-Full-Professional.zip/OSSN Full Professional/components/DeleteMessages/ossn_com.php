<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

define('__DELETE_MESSAGES__', ossn_route()->com . 'DeleteMessages/');
require_once(__DELETE_MESSAGES__ . 'classes/DeleteMessages.php');

function com_delete_messages_init() {
	ossn_extend_view('js/opensource.socialnetwork', 'DeleteMessages/button.js');
	if(ossn_isAdminLoggedin()){
		ossn_register_com_panel('DeleteMessages', 'deletemessages');
		ossn_register_action('DeleteMessages/admin/deletemessages', __DELETE_MESSAGES__ . 'actions/DeleteMessages/admin/deletemessages.php');		
	}
}

ossn_register_callback('ossn', 'init', 'com_delete_messages_init');
