<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$en = array(
	'deletemessages' => 'Delete Messages',
	'com:delete:messages:instruction' => 'Clicking the <b>[ Delete ]</b> button below will delete any messages from your community which are older than the chosen number of days.<br>
	You may simulate deletion, first - in order to get an idea how many messages will be involved.<br><br>
	Be careful: the smaller the number of days, the more messages will be deleted.<br>
	That is: Entering zero days will delete ALL messages!',
	'com:delete:messages:input:days:count' => 'Enter the age of the messages <small>(the default is 28 days)</small',
	'com:delete:messages:checkbox:simulate:delete' => 'Only simulate deletion',
	'com:delete:messages:button:delete' => 'Delete',
	'com:delete:messages:msg:none' => 'No messages found which are older than %s days',
	'com:delete:messages:msg:simulated' => '%s messages would have been deleted',
	'com:delete:messages:msg:deleted' => '%s messages successfully deleted',
);
ossn_register_languages('fr', $en); 
