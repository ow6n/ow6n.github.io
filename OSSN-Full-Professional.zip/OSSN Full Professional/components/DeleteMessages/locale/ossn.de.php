<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$en = array(
	'deletemessages' => 'Delete Messages',
	'com:delete:messages:instruction' => 'Wenn du unten auf den <b>[ Löschen ]</b> Knopf klickst, werden alle Nachrichten in deiner Community gelöscht, die älter sind als die gewählte Anzahl von Tagen.<br>
	Du kannst das Löschen vorab simulieren um eine Vorstellung davon zu bekommen, wie viele Nachrichten überhaupt betroffen sind.<br><br>
	Und Vorsicht: Je kleiner die Anzahl der Tage, desto mehr Nachrichten werden gelöscht.<br>
	Das heißt: Bei Eingabe von Null Tagen werden ALLE Nachrichten gelöscht!',
	'com:delete:messages:input:days:count' => 'Gib das Alter der Nachrichten ein <small>(älter als 28 Tage ist der Standardwert)</small>. ',
	'com:delete:messages:checkbox:simulate:delete' => 'das Löschen nur simulieren',
	'com:delete:messages:button:delete' => 'Löschen',
	'com:delete:messages:msg:none' => 'Es wurden keine Nachrichten gefunden, die älter als %s Tage sind',
	'com:delete:messages:msg:simulated' => '%s Nachrichten wären gelöscht worden',
	'com:delete:messages:msg:deleted' => '%s Nachrichten wurden erfolgreich gelöscht',
);
ossn_register_languages('de', $en); 
