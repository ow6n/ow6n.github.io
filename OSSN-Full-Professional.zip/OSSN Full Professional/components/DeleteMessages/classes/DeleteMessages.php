<?php

/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
class DeleteMessages extends OssnDatabase {

		public function deleteMessagesOlderThan($days, $simulate = true) {
			$params           = array();
			$params['params'] = array(
					'id'
			);
			$params['from']   = "ossn_messages";
			$params['wheres'] = array(
					"time < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL {$days} DAY))"
			);
			$message_ids = $this->select($params, true);
			
			if($message_ids) {
				$deleted_messages = count((array) $message_ids);
				$message_id_list = implode(',', array_map(function($x) { return $x->id; }, (array) $message_ids));

				if(!$simulate) {
					$params           = array();
					$params['params'] = array(
						'guid'
					);
					$params['from']   = "ossn_entities";
					$params['wheres'] = array(
						"owner_guid IN ({$message_id_list}) AND type = 'message'"
					);
					$entity_guids = $this->select($params, true);

					if($entity_guids) {
						$entity_guid_list = implode(',', array_map(function($x) { return $x->guid; }, (array) $entity_guids));
						$this->delete(array(
							'from' => 'ossn_entities_metadata',
							'wheres' => array(
								"guid IN ({$entity_guid_list})"
							)
						));
						$this->delete(array(
							'from' => 'ossn_entities',
							'wheres' => array(
								"guid IN ({$entity_guid_list})"
							)
						));
					}
				
					$this->delete(array(
						'from' => 'ossn_messages',
						'wheres' => array(
							"id IN ({$message_id_list})"
						)
					));
				}
				return $deleted_messages;
			}
			return false;
		}

}