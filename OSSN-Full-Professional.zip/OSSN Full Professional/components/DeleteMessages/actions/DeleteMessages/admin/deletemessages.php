<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */


$days     = abs ((int) input('count'));
$simulate = input('simulate_delete');

if($simulate === 'checked') {
	$simulate = true;
} else {
	$simulate = false;
}

$messages = new DeleteMessages();
if (!$deleted_messages = $messages->deleteMessagesOlderThan($days, $simulate)) {
	ossn_trigger_message(ossn_print('com:delete:messages:msg:none', array($days)));
	redirect(REF);
	exit;
}
if($simulate) {
	ossn_trigger_message(ossn_print('com:delete:messages:msg:simulated', array($deleted_messages)));
	redirect(REF);
	exit;
} else{
	ossn_trigger_message(ossn_print('com:delete:messages:msg:deleted', array($deleted_messages)));
	redirect(REF);
	exit;
}	

